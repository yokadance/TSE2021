package uy.vacunas.ui.vaccinators;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class VaccinatorsViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public VaccinatorsViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Estoy en vacunatorios");
    }

    public LiveData<String> getText() {
        return mText;
    }
}