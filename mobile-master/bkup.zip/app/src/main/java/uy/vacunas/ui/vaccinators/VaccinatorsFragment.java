package uy.vacunas.ui.vaccinators;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.loader.app.LoaderManager;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import java.util.ArrayList;

import uy.vacunas.R;

public class VaccinatorsFragment extends Fragment {

    private ArrayList<LatLng> locationArrayList = new ArrayList<LatLng>();

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {


        View view = inflater.inflate(R.layout.fragment_vaccinator_centers_maps, container, false);

        LatLng v1 = new LatLng(-34.907958546918636, -56.188465204047944);
        LatLng v2 = new LatLng(-34.867498544996394, -56.16587813266254);
        LatLng v3 = new LatLng(-34.74225705516956, -56.091243171099535);
        LatLng v4 = new LatLng(-34.8356768227661, -56.01688069666219);
        LatLng v5 = new LatLng(-34.70797613238846, -56.20128548241474);
        locationArrayList.add(v1);
        locationArrayList.add(v2);
        locationArrayList.add(v3);
        locationArrayList.add(v4);
        locationArrayList.add(v5);
        SupportMapFragment supportMapFragment = (SupportMapFragment)
                getChildFragmentManager().findFragmentById(R.id.map);
        FusedLocationProviderClient client;
        client = LocationServices.getFusedLocationProviderClient(getActivity());

        supportMapFragment.getMapAsync(new OnMapReadyCallback() {

            @Override
            public void onMapReady(GoogleMap googleMap) {


                if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    googleMap.setMyLocationEnabled(true);
                    googleMap.getUiSettings().setMyLocationButtonEnabled(true);


                }else{
                    ActivityCompat.requestPermissions(getActivity(),new String[]{Manifest.permission.ACCESS_FINE_LOCATION},44);
                }
                getCurrentLocation();
                for (int i = 0; i < locationArrayList.size(); i++) {

                    // below line is use to add marker to each location of our array list.
                    googleMap.addMarker(new MarkerOptions().position(locationArrayList.get(i)).title("Nombre").snippet("otra cosa"));

                }
                float zoomLevel = 10.0f; //This goes up to 21
                googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(v1, zoomLevel));

                /*googleMap.addMarker(new MarkerOptions().position(uruguay).title("Vacunatorio 1").snippet("Subtitulo"));
                googleMap.addMarker(new MarkerOptions().position(v2).title("Vacunatorio 2").snippet("Subtitulo"));
                googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(uruguay, zoomLevel));*/

                googleMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
                    @Override
                    public void    onMapClick(LatLng latLng) {/*
                        MarkerOptions markerOptions = new MarkerOptions();
                        markerOptions.position(latLng);
                        markerOptions.title(latLng.latitude + " : " + latLng.longitude);
                        googleMap.clear();
                        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(
                                latLng, 8
                        ));
                        googleMap.addMarker(markerOptions);
                        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                            googleMap.setMyLocationEnabled(true);
                            googleMap.getUiSettings().setMyLocationButtonEnabled(true);


                        }else{
                            ActivityCompat.requestPermissions(getActivity(),new String[]{Manifest.permission.ACCESS_FINE_LOCATION},44);
                        }


                    */}
                });
            }

            private void getCurrentLocation() {
                if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    Task<Location> task = client.getLastLocation();
                    task.addOnSuccessListener(new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            if(location !=null){
                                supportMapFragment.getMapAsync(new OnMapReadyCallback() {
                                    @Override
                                    public void onMapReady(GoogleMap googleMap) {
                                        for (int i = 0; i < locationArrayList.size(); i++) {

                                            // below line is use to add marker to each location of our array list.
                                            googleMap.addMarker(new MarkerOptions().position(locationArrayList.get(i)).title("Nombre").snippet("otra cosa"));

                                        }
                                        /*
                                        MarkerOptions options = new MarkerOptions().position(latLng).title("Aqui estas tu");
                                        options.snippet(latLng.latitude +" : "+ latLng.longitude);

                                        googleMap.addMarker(options);*/
                                        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
                                        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,10));

                                    }
                                });
                            }
                        }
                    });
                    //return;
                }


            }


        });

        return view;

    }

}
